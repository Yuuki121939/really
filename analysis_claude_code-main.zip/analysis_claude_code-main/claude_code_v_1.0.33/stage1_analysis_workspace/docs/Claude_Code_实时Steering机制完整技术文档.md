# Claude Code 实时Steering机制完整技术文档

## 概述

本文档基于对Claude Code混淆源码的深度分析，详细阐述其实时Steering机制的完整实现。该机制允许用户在Claude执行任务时实时发送消息进行交互和引导，打破了传统Agent系统的同步阻塞限制。

## 核心架构概览

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   stdin监听      │───▶│  消息解析器      │───▶│  异步消息队列    │
│  (实时输入)      │    │   (g2A)         │    │    (h2A)        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                                                        ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  AbortController │◀───│   流式处理      │◀───│   Agent循环     │
│   (中断控制)     │    │   (kq5)         │    │    (nO)         │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 1. 异步消息队列系统 (h2A类)

### 1.1 核心实现

```javascript
// 位置: improved-claude-code-5.mjs:68934-68993
class h2A {
  returned;           // 清理函数
  queue = [];         // 消息队列缓冲区
  readResolve;        // Promise resolve回调
  readReject;         // Promise reject回调
  isDone = false;     // 队列完成标志
  hasError;           // 错误状态
  started = false;    // 启动状态标志

  constructor(A) {
    this.returned = A  // 设置清理回调
  }

  // 实现AsyncIterator接口
  [Symbol.asyncIterator]() {
    if (this.started) 
      throw new Error("Stream can only be iterated once");
    this.started = true;
    return this;
  }

  // 核心异步迭代器方法
  next() {
    // 优先从队列中取消息
    if (this.queue.length > 0) {
      return Promise.resolve({
        done: false,
        value: this.queue.shift()
      });
    }
    
    // 队列完成时返回结束标志
    if (this.isDone) {
      return Promise.resolve({
        done: true,
        value: undefined
      });
    }
    
    // 有错误时拒绝Promise
    if (this.hasError) {
      return Promise.reject(this.hasError);
    }
    
    // 等待新消息 - 关键的非阻塞机制
    return new Promise((resolve, reject) => {
      this.readResolve = resolve;
      this.readReject = reject;
    });
  }

  // 消息入队 - 支持实时消息插入
  enqueue(A) {
    if (this.readResolve) {
      // 如果有等待的读取，直接返回消息
      let callback = this.readResolve;
      this.readResolve = undefined;
      this.readReject = undefined;
      callback({
        done: false,
        value: A
      });
    } else {
      // 否则推入队列缓冲
      this.queue.push(A);
    }
  }

  // 完成队列
  done() {
    this.isDone = true;
    if (this.readResolve) {
      let callback = this.readResolve;
      this.readResolve = undefined;
      this.readReject = undefined;
      callback({
        done: true,
        value: undefined
      });
    }
  }

  // 错误处理
  error(A) {
    this.hasError = A;
    if (this.readReject) {
      let callback = this.readReject;
      this.readResolve = undefined;
      this.readReject = undefined;
      callback(A);
    }
  }
}
```

### 1.2 技术特点

- **非阻塞设计**: 使用Promise和回调机制实现非阻塞的消息读取
- **双重缓冲**: 支持队列缓冲和直接传递两种模式
- **状态管理**: 完整的生命周期状态管理
- **错误恢复**: 内置错误处理和传播机制

## 2. 消息解析器 (g2A类)

### 2.1 流式解析实现

```javascript
// 位置: improved-claude-code-5.mjs:68893-68928
class g2A {
  input;            // 原始输入流
  structuredInput;  // 结构化输入流

  constructor(A) {
    this.input = A;
    this.structuredInput = this.read();
  }

  // 异步生成器 - 流式处理输入
  async *read() {
    let buffer = "";
    
    // 逐字符处理输入流
    for await (let chunk of this.input) {
      buffer += chunk;
      let lineEnd;
      
      // 按行分割处理
      while ((lineEnd = buffer.indexOf('\n')) !== -1) {
        let line = buffer.slice(0, lineEnd);
        buffer = buffer.slice(lineEnd + 1);
        
        let parsed = this.processLine(line);
        if (parsed) yield parsed;
      }
    }
    
    // 处理最后一行
    if (buffer) {
      let parsed = this.processLine(buffer);
      if (parsed) yield parsed;
    }
  }

  // 单行消息解析
  processLine(line) {
    try {
      let message = JSON.parse(line);
      
      // 严格类型验证
      if (message.type !== "user") {
        throw new Error(`Expected message type 'user', got '${message.type}'`);
      }
      
      if (message.message.role !== "user") {
        throw new Error(`Expected message role 'user', got '${message.message.role}'`);
      }
      
      return message;
    } catch (error) {
      console.error(`Error parsing streaming input line: ${line}: ${error}`);
      process.exit(1);
    }
  }
}
```

### 2.2 安全特性

- **类型验证**: 严格验证消息类型和角色
- **错误处理**: 解析失败时提供详细错误信息
- **流式处理**: 支持大消息的分块处理
- **状态安全**: 无状态设计，避免状态污染

## 3. 流式消息处理引擎 (kq5函数)

### 3.1 核心调度逻辑

```javascript
// 位置: improved-claude-code-5.mjs:69363-69421
function kq5(inputStream, permissionContext, mcpClients, commands, tools, 
            toolConfig, permissionTool, options) {
  let commandQueue = [];          // 命令队列
  let getQueuedCommands = () => commandQueue;  // 队列访问器
  let removeQueuedCommands = (commands) => {   // 队列清理器
    commandQueue = commandQueue.filter(cmd => !commands.includes(cmd));
  };
  
  let isExecuting = false;        // 执行状态标志
  let isCompleted = false;        // 完成状态标志
  let outputStream = new h2A();   // 输出队列
  let messageHistory = processInitialMessages(toolConfig);

  // 异步执行引擎
  let executeCommands = async () => {
    isExecuting = true;
    try {
      // 处理队列中的所有命令
      while (commandQueue.length > 0) {
        let command = commandQueue.shift();
        
        // 仅支持prompt命令
        if (command.mode !== "prompt") {
          throw new Error("only prompt commands are supported in streaming mode");
        }
        
        let prompt = command.value;
        
        // 调用主Agent执行循环 - 关键调用点
        for await (let result of Zk2({
          commands: commands,
          prompt: prompt,
          cwd: getCurrentWorkingDirectory(),
          tools: tools,
          permissionContext: permissionContext,
          verbose: options.verbose,
          mcpClients: mcpClients,
          maxTurns: options.maxTurns,
          permissionPromptTool: permissionTool,
          userSpecifiedModel: options.userSpecifiedModel,
          fallbackModel: options.fallbackModel,
          initialMessages: messageHistory,
          customSystemPrompt: options.systemPrompt,
          appendSystemPrompt: options.appendSystemPrompt,
          getQueuedCommands: getQueuedCommands,
          removeQueuedCommands: removeQueuedCommands
        })) {
          messageHistory.push(result);    // 更新消息历史
          outputStream.enqueue(result);   // 输出到流
        }
      }
    } finally {
      isExecuting = false;  // 确保状态重置
    }
    
    if (isCompleted) outputStream.done();
  };

  // 输入处理协程
  let processInput = async () => {
    for await (let message of inputStream) {
      let promptContent;
      
      // 提取消息内容 - 支持多种格式
      if (typeof message.message.content === "string") {
        promptContent = message.message.content;
      } else {
        if (message.message.content.length !== 1) {
          console.error(`Error: Expected exactly one content item, got ${message.message.content.length}`);
          process.exit(1);
        }
        
        if (typeof message.message.content[0] === "string") {
          promptContent = message.message.content[0];
        } else if (message.message.content[0].type === "text") {
          promptContent = message.message.content[0].text;
        } else {
          console.error("Error: Expected string or text block content");
          process.exit(1);
        }
      }
      
      // 新消息入队
      commandQueue.push({
        mode: "prompt",
        value: promptContent
      });
      
      // 如果未在执行，启动执行
      if (!isExecuting) executeCommands();
    }
    
    isCompleted = true;
    if (!isExecuting) outputStream.done();
  };

  // 启动输入处理
  processInput();
  
  return outputStream;  // 返回输出流
}
```

### 3.2 并发控制特性

- **状态同步**: 使用标志位确保执行状态的正确性
- **队列管理**: 支持动态的命令入队和出队
- **非阻塞执行**: 新消息不会阻塞当前执行
- **流式输出**: 通过异步队列实现流式输出

## 4. Agent主循环 (nO函数)

### 4.1 Async Generator实现

```javascript
// 位置: improved-claude-code-5.mjs:46187-46300+
async function* nO(messages, user, prompt, tools, context, agentContext, 
                   turnData, fallbackModel, options) {
  // 流开始标记
  yield { type: "stream_request_start" };
  
  let currentMessages = messages;
  let currentTurnData = turnData;
  
  // 消息压缩处理
  let { messages: compactedMessages, wasCompacted } = await compactMessages(messages, agentContext);
  if (wasCompacted) {
    logEvent("tengu_auto_compact_succeeded", {
      originalMessageCount: messages.length,
      compactedMessageCount: compactedMessages.length
    });
    
    if (!currentTurnData?.compacted) {
      currentTurnData = {
        compacted: true,
        turnId: generateTurnId(),
        turnCounter: 0
      };
    }
    currentMessages = compactedMessages;
  }
  
  let assistantResponses = [];
  let currentModel = agentContext.options.mainLoopModel;
  let shouldRetry = true;
  
  try {
    // 主执行循环 - 支持模型降级重试
    while (shouldRetry) {
      shouldRetry = false;
      
      try {
        // 调用核心AI处理循环 - 关键yield点
        for await (let response of processWithAI(
          buildMessages(currentMessages, prompt),
          buildContext(user, tools),
          agentContext.options.maxThinkingTokens,
          agentContext.options.tools,
          agentContext.abortController.signal,  // 传递中断信号
          {
            getToolPermissionContext: agentContext.getToolPermissionContext,
            model: currentModel,
            prependCLISysprompt: true,
            toolChoice: undefined,
            isNonInteractiveSession: agentContext.options.isNonInteractiveSession,
            fallbackModel: fallbackModel
          }
        )) {
          // 流式输出每个响应 - 实现非阻塞
          yield response;
          
          if (response.type === "assistant") {
            assistantResponses.push(response);
          }
        }
      } catch (error) {
        // 模型降级处理
        if (error instanceof ModelError && fallbackModel) {
          currentModel = fallbackModel;
          shouldRetry = true;
          assistantResponses.length = 0;
          agentContext.options.mainLoopModel = fallbackModel;
          
          logEvent("tengu_model_fallback_triggered", {
            original_model: error.originalModel,
            fallback_model: fallbackModel,
            entrypoint: "cli"
          });
          
          yield createLogMessage(`Model fallback triggered: switching from ${error.originalModel} to ${error.fallbackModel}`, "info");
          continue;
        }
        throw error;
      }
    }
  } catch (error) {
    // 错误处理和工具结果生成
    logError(error instanceof Error ? error : new Error(String(error)));
    let errorMessage = error instanceof Error ? error.message : String(error);
    
    logEvent("tengu_query_error", {
      assistantMessages: assistantResponses.length,
      toolUses: assistantResponses.flatMap(resp => 
        resp.message.content.filter(content => content.type === "tool_use")).length
    });
    
    // 为每个工具使用生成错误结果
    let hasToolResults = false;
    for (let response of assistantResponses) {
      let toolUses = response.message.content.filter(content => content.type === "tool_use");
      for (let toolUse of toolUses) {
        yield createToolResult({
          content: [{
            type: "tool_result",
            content: errorMessage,
            is_error: true,
            tool_use_id: toolUse.id
          }],
          toolUseResult: errorMessage
        });
        hasToolResults = true;
      }
    }
    
    if (!hasToolResults) {
      yield createSystemMessage({
        toolUse: false,
        hardcodedMessage: undefined
      });
    }
    return;
  }
  
  // 后续工具处理逻辑...
  if (!assistantResponses.length) return;
  
  let toolUses = assistantResponses.flatMap(response => 
    response.message.content.filter(content => content.type === "tool_use"));
  
  if (!toolUses.length) return;
  
  let toolResults = [];
  let shouldPreventContinuation = false;
  
  // 执行工具调用
  for await (let result of executeTools(toolUses, assistantResponses, context, agentContext)) {
    yield result;  // 流式输出工具结果
    
    if (result && result.type === "system" && result.preventContinuation) {
      shouldPreventContinuation = true;
    }
    
    toolResults.push(...filterUserMessages([result]));
  }
  
  // 检查是否被中断
  if (agentContext.abortController.signal.aborted) {
    yield createSystemMessage({
      toolUse: true,
      hardcodedMessage: undefined
    });
    return;
  }
  
  if (shouldPreventContinuation) return;
  
  // 继续处理...
}
```

### 4.2 关键技术特性

- **Async Generator**: 使用yield实现非阻塞的流式处理
- **中断检查**: 在多个关键点检查AbortController信号
- **状态保持**: 通过生成器状态保持执行上下文
- **错误恢复**: 完整的错误处理和恢复机制
- **模型降级**: 支持模型故障时的自动降级

## 5. AbortController中断机制

### 5.1 中断控制器创建

```javascript
// 位置: improved-claude-code-5.mjs:69070
let agentContext = {
  messages: messages,
  setMessages: () => {},
  onChangeAPIKey: () => {},
  options: {
    commands: commands,
    debug: false,
    tools: tools,
    verbose: verbose,
    mainLoopModel: getModel(),
    maxThinkingTokens: calculateMaxTokens(messages),
    mcpClients: mcpClients,
    mcpResources: {},
    ideInstallationStatus: null,
    isNonInteractiveSession: true,
    theme: getTheme().theme
  },
  getToolPermissionContext: () => permissionContext,
  getQueuedCommands: () => [],
  removeQueuedCommands: () => {},
  abortController: new AbortController(),  // 每个Agent实例独立的中断控制器
  readFileState: {},
  setInProgressToolUseIDs: () => {},
  setToolPermissionContext: () => {},
  agentId: generateAgentId()
};
```

### 5.2 中断信号传播

```javascript
// 中断信号在整个调用链中传播
for await (let response of processWithAI(
  buildMessages(currentMessages, prompt),
  buildContext(user, tools),
  agentContext.options.maxThinkingTokens,
  agentContext.options.tools,
  agentContext.abortController.signal,  // 中断信号传递
  processingOptions
)) {
  yield response;
}

// 中断状态检查
if (agentContext.abortController.signal.aborted) {
  yield createSystemMessage({
    toolUse: true,
    hardcodedMessage: undefined
  });
  return;
}
```

### 5.3 中断处理机制

```javascript
// 位置: improved-claude-code-5.mjs:4903-4906 及相关代码
// 中断事件监听
if (abortController.once("abort", cleanupCallback), 
    options.cancelToken || options.signal) {
  
  if (options.cancelToken && options.cancelToken.subscribe(abortHandler)) {
    // 处理取消令牌
  }
  
  if (options.signal) {
    if (options.signal.aborted) {
      abortHandler();
    } else {
      options.signal.addEventListener("abort", abortHandler);
    }
  }
}

// 复合中断控制器 - 支持多源中断
function createCompositeAbortController(sources, cleanup) {
  let compositeController = new AbortController();
  let isAborted = false;
  
  let abortHandler = function(event) {
    if (!isAborted) {
      isAborted = true;
      cleanup();
      let error = event instanceof Error ? 
        event : this.reason;
      compositeController.abort(
        error instanceof AbortError ? 
        error : new AbortError(error instanceof Error ? error.message : error)
      );
    }
  };
  
  // 监听所有源的中断事件
  sources.forEach(source => {
    source.addEventListener("abort", abortHandler);
  });
  
  let { signal } = compositeController;
  signal.unsubscribe = () => scheduleMicrotask(cleanup);
  return signal;
}
```

## 6. 实时输入监听系统

### 6.1 标准输入监听

```javascript
// 位置: improved-claude-code-5.mjs:49065
// 全局stdin监听初始化
let initializeStdinListener = once(() => 
  process.stdin.on("data", handleFocusChange)
);

// 位置: improved-claude-code-5.mjs:53568-53570
// 焦点检测的stdin监听
if (focusListeners.add(callback), focusListeners.size === 1) {
  process.stdout.write("\x1B[?1004h");  // 启用焦点报告
  process.stdin.on("data", handleFocusEvents);
}

// 清理机制
return () => {
  if (focusListeners.delete(callback), focusListeners.size === 0) {
    process.stdin.off("data", handleFocusEvents);
    process.stdout.write("\x1B[?1004l");  // 禁用焦点报告
  }
};

// 位置: improved-claude-code-5.mjs:67405-67407
// 键盘输入监听
useEffect(() => {
  return process.stdin.on("data", handleKeyPress), () => {
    process.stdin.off("data", handleKeyPress);
  };
}, [onDismiss]);
```

### 6.2 输入数据处理

```javascript
// 焦点序列过滤
let filterFocusSequences = useCallback((data, hasTyped) => {
  // 过滤终端焦点控制序列
  if (data === "\x1B[I" || data === "\x1B[O" || 
      data === "[I" || data === "[O") {
    return "";
  }
  
  // 处理用户输入状态
  if ((data || hasTyped) && !isFocused) {
    setHasTyped(true);
  }
  
  return data;
}, [isFocused]);
```

## 7. 消息流处理管道

### 7.1 消息流转路径

```
用户输入(stdin) 
    ↓
输入监听器(process.stdin.on)
    ↓
消息解析器(g2A.processLine)
    ↓
队列入队(h2A.enqueue)
    ↓
流式处理器(kq5)
    ↓
Agent循环(nO)
    ↓
AI处理(wu/processWithAI)
    ↓
工具执行(executeTools)
    ↓
结果输出(yield)
```

### 7.2 并发安全机制

```javascript
// 队列状态同步
let commandQueue = [];
let isExecuting = false;
let isCompleted = false;

// 安全的队列操作
let addCommand = (command) => {
  commandQueue.push(command);
  if (!isExecuting) {
    executeCommands();  // 非阻塞启动执行
  }
};

// 执行状态保护
let executeCommands = async () => {
  isExecuting = true;
  try {
    while (commandQueue.length > 0) {
      let command = commandQueue.shift();
      // 执行命令...
    }
  } finally {
    isExecuting = false;  // 确保状态重置
  }
  
  if (isCompleted) {
    outputStream.done();
  }
};
```

## 8. 技术优势与创新点

### 8.1 架构优势

1. **真正的异步处理**: 
   - 使用async generator而非同步循环
   - Promise-based的非阻塞队列机制
   - 流式处理避免内存积压

2. **多层次的状态管理**:
   - 队列级状态(h2A)
   - 处理器级状态(kq5)
   - Agent级状态(nO)
   - 工具级状态(AbortController)

3. **完整的错误恢复**:
   - 分层错误处理
   - 优雅的中断机制
   - 模型降级策略
   - 状态一致性保证

### 8.2 性能特性

1. **低延迟响应**:
   - 直接回调机制避免轮询
   - 队列缓冲减少等待
   - yield点提供及时的中断机会

2. **内存效率**:
   - 流式处理避免大量缓存
   - 按需处理减少内存占用
   - 自动清理机制

3. **并发安全**:
   - 无锁设计避免死锁
   - 状态标志确保一致性
   - 异步机制提高吞吐量

## 9. 实现指导原则

### 9.1 开源实现要点

1. **核心组件实现**:
   ```javascript
   // 必须实现的核心类
   class AsyncMessageQueue {
     // 实现h2A的功能
   }
   
   class MessageParser {
     // 实现g2A的功能  
   }
   
   class StreamProcessor {
     // 实现kq5的功能
   }
   
   async function* agentLoop() {
     // 实现nO的功能
   }
   ```

2. **关键设计模式**:
   - AsyncIterator模式用于流式处理
   - Promise/回调混合用于非阻塞
   - Generator用于可中断执行
   - ObserverPattern用于状态通知

3. **必要的基础设施**:
   - AbortController集成
   - 进程信号处理
   - 错误边界处理
   - 状态同步机制

### 9.2 测试验证策略

1. **功能验证**:
   - 消息队列的入队/出队正确性
   - 中断信号的传播和响应
   - 并发情况下的状态一致性
   - 错误情况下的恢复能力

2. **性能验证**:
   - 高频消息的处理能力
   - 内存使用的稳定性
   - 响应延迟的测量
   - 长时间运行的稳定性

## 10. 结论

Claude Code的实时Steering机制代表了Agent系统架构的重大创新：

1. **突破传统限制**: 打破了同步执行的束缚，实现真正的实时交互
2. **架构先进性**: 使用现代异步编程模式，实现高效的并发处理
3. **工程完整性**: 包含完整的错误处理、状态管理和性能优化
4. **实用价值**: 为开源Agent系统提供了可行的实现路径

这一机制的深度分析不仅揭示了Claude Code的技术实力，也为整个AI Agent领域提供了宝贵的技术参考和实现指导。

---

**文档版本**: 1.0  
**分析日期**: 2025-06-27  
**基于源码**: improved-claude-code-5.mjs (及相关文件)  
**分析深度**: 完整源码级别验证